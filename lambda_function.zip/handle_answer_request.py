#!/usr/bin/env python
"""
Train That Brain
v1.0.0
github.com/irlrobot/train_that_brain
"""
from __future__ import print_function

def handle_answer_request(intent, session):
    """check if the answer is right, adjust score, and continue"""
    return 'blah'
